
import { Component, ChangeDetectionStrategy, signal } from '@angular/core';
import { StoryGeneratorComponent } from './components/story-generator/story-generator.component';
import { CharacterGeneratorComponent } from './components/character-generator/character-generator.component';
import { ImageGeneratorComponent } from './components/image-generator/image-generator.component';
import { VideoGeneratorComponent } from './components/video-generator/video-generator.component';

type ActiveTab = 'story' | 'character' | 'image' | 'video';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [StoryGeneratorComponent, CharacterGeneratorComponent, ImageGeneratorComponent, VideoGeneratorComponent]
})
export class AppComponent {
  activeTab = signal<ActiveTab>('story');

  selectTab(tab: ActiveTab) {
    this.activeTab.set(tab);
  }
}
