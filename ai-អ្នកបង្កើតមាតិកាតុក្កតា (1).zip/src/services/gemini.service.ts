
import { Injectable } from '@angular/core';
import { GoogleGenAI } from '@google/genai';

@Injectable({
  providedIn: 'root',
})
export class GeminiService {
  private ai: GoogleGenAI;

  constructor() {
    // This assumes process.env.API_KEY is available in the execution context,
    // as per the applet environment's requirements.
    if (!process.env.API_KEY) {
        console.error("API Key not found. Please ensure it is set in the environment variables.");
        // In a real app, you would handle this more gracefully, but for the applet,
        // we rely on the environment providing the key.
    }
    this.ai = new GoogleGenAI({ apiKey: process.env.API_KEY as string });
  }

  async generateStory(prompt: string): Promise<string> {
    try {
      const response = await this.ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: `Generate a short cartoon story based on the following prompt. The story should be imaginative, engaging, and suitable for all ages. Prompt: "${prompt}"`,
      });
      return response.text;
    } catch (error) {
      console.error('Error generating story:', error);
      throw new Error('ការបង្កើតរឿងបានបរាជ័យ។ សូមពិនិត្យមើលកុងសូលសម្រាប់ព័ត៌មានលម្អិត។');
    }
  }

  async generateCharacter(prompt: string): Promise<string> {
    try {
      const response = await this.ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: `Create a detailed cartoon character description based on the following idea. Include their name, appearance, personality, backstory, and a unique quirk. Idea: "${prompt}"`,
      });
      return response.text;
    } catch (error) {
      console.error('Error generating character:', error);
      throw new Error('ការបង្កើតការពិពណ៌នាតួអក្សរបានបរាជ័យ។ សូមពិនិត្យមើលកុងសូលសម្រាប់ព័ត៌មានលម្អិត។');
    }
  }

  async generateImage(prompt: string): Promise<string> {
    try {
      const response = await this.ai.models.generateImages({
        model: 'imagen-4.0-generate-001',
        prompt: `A vibrant, cartoon-style illustration of: ${prompt}. Clean lines, bright colors, friendly aesthetic.`,
        config: {
          numberOfImages: 1,
          outputMimeType: 'image/png',
          aspectRatio: '1:1',
        },
      });
      const base64ImageBytes: string = response.generatedImages[0].image.imageBytes;
      return `data:image/png;base64,${base64ImageBytes}`;
    } catch (error)
{
      console.error('Error generating image:', error);
      throw new Error('ការបង្កើតរូបភាពបានបរាជ័យ។ សូមពិនិត្យមើលកុងសូលសម្រាប់ព័ត៌មានលម្អិត។');
    }
  }

  async generateVideo(prompt: string): Promise<string> {
    try {
      let operation: any = await this.ai.models.generateVideos({
        model: 'veo-2.0-generate-001',
        prompt: `Create a short, vibrant, family-friendly cartoon animation based on this description: ${prompt}. The style should be playful with clean lines and bright colors.`,
        config: {
          numberOfVideos: 1
        }
      });

      while (!operation.done) {
        // Wait for 10 seconds before polling again
        await new Promise(resolve => setTimeout(resolve, 10000));
        operation = await this.ai.operations.getVideosOperation({ operation: operation });
      }

      const downloadLink = operation.response?.generatedVideos?.[0]?.video?.uri;
      if (!downloadLink) {
          throw new Error('មិនអាចទាញយកតំណទាញយកវីដេអូបានទេ។');
      }

      return downloadLink;

    } catch (error: any) {
      console.error('Error generating video:', error);
      const errorString = JSON.stringify(error);
      if (errorString.includes('PERMISSION_DENIED')) {
         throw new Error('ការបង្កើតវីដេអូបានបរាជ័យដោយសារបញ្ហាការអនុញ្ញាត។ សូមប្រាកដថាសោ API របស់អ្នកត្រឹមត្រូវ និងមានសិទ្ធិសម្រាប់បង្កើតវីដេអូ។');
      }
      throw new Error('ការបង្កើតវីដេអូបានបរាជ័យ។ សូមពិនិត្យមើលកុងសូលសម្រាប់ព័ត៌មានលម្អិត។');
    }
  }
  
  async translateText(text: string, targetLanguage: string): Promise<string> {
    try {
      const response = await this.ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: `Translate the following text into ${targetLanguage}:\n\n"${text}"`,
      });
      return response.text;
    } catch (error) {
      console.error('Error translating text:', error);
      throw new Error(`ការបកប្រែទៅជា ${targetLanguage} បានបរាជ័យ។`);
    }
  }
}
