
import { Component, ChangeDetectionStrategy, inject, signal, OnDestroy } from '@angular/core';
import { GeminiService } from '../../services/gemini.service';

@Component({
  selector: 'app-video-generator',
  templateUrl: './video-generator.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class VideoGeneratorComponent implements OnDestroy {
  private geminiService = inject(GeminiService);

  prompt = signal('ឆ្មាមួយក្បាលជិះក្តារស្គីក្នុងលំហអាកាស មានផ្កាយ និងភពនានានៅផ្ទៃខាងក្រោយ។');
  result = signal<string | null>(null);
  isLoading = signal(false);
  error = signal<string | null>(null);
  
  private loadingMessages = [
    'កំពុង​កម្តៅ​កាមេរ៉ា​និម្មិត...',
    'កំពុងបង្ហាញ​ស៊ុម​ដំបូង​មួយ​ចំនួន...',
    'កំពុង​បន្ថែម​បែបផែន​ពិសេស...',
    'កំពុង​បញ្ចប់​គំនូរជីវចល...',
    'វា​អាច​ចំណាយ​ពេល​ពីរ​បី​នាទី សូម​មេត្តា​រង់ចាំ។'
  ];
  loadingMessage = signal(this.loadingMessages[0]);
  private messageInterval: any;

  ngOnDestroy() {
    if (this.messageInterval) {
      clearInterval(this.messageInterval);
    }
    // Revoke the object URL to prevent memory leaks
    if (this.result()) {
      URL.revokeObjectURL(this.result()!);
    }
  }

  async generateVideo() {
    if (!this.prompt().trim()) return;

    this.isLoading.set(true);
    if (this.result()) {
        URL.revokeObjectURL(this.result()!);
    }
    this.result.set(null);
    this.error.set(null);

    // Start cycling loading messages
    let messageIndex = 0;
    this.loadingMessage.set(this.loadingMessages[messageIndex]);
    this.messageInterval = setInterval(() => {
      messageIndex = (messageIndex + 1) % this.loadingMessages.length;
      this.loadingMessage.set(this.loadingMessages[messageIndex]);
    }, 5000);

    try {
      const downloadLink = await this.geminiService.generateVideo(this.prompt());
      
      const apiKey = process.env.API_KEY;
      if (!apiKey) {
        throw new Error('API Key is not configured for fetching video.');
      }
      
      const fetchUrl = new URL(downloadLink);
      fetchUrl.searchParams.append('key', apiKey);

      const response = await fetch(fetchUrl.toString());
      if (!response.ok) {
        throw new Error(`Failed to fetch video: ${response.statusText}`);
      }
      const videoBlob = await response.blob();
      const videoUrl = URL.createObjectURL(videoBlob);
      this.result.set(videoUrl);

    } catch (e: any) {
      this.error.set(e.message || 'មានកំហុសមិនស្គាល់មួយបានកើតឡើង។');
    } finally {
      this.isLoading.set(false);
      clearInterval(this.messageInterval);
    }
  }

  updatePrompt(event: Event) {
    const input = event.target as HTMLTextAreaElement;
    this.prompt.set(input.value);
  }
}
