
import { Component, ChangeDetectionStrategy, inject, signal } from '@angular/core';
import { GeminiService } from '../../services/gemini.service';

@Component({
  selector: 'app-character-generator',
  templateUrl: './character-generator.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class CharacterGeneratorComponent {
  private geminiService = inject(GeminiService);

  prompt = signal('gnome ដែលមិនចេះរីករាយដែលជាអ្នកថែសួនដ៏ឆ្នើមដោយសម្ងាត់។');
  result = signal<string | null>(null);
  isLoading = signal(false);
  error = signal<string | null>(null);

  async generateCharacter() {
    if (!this.prompt().trim()) return;

    this.isLoading.set(true);
    this.result.set(null);
    this.error.set(null);

    try {
      const character = await this.geminiService.generateCharacter(this.prompt());
      this.result.set(character);
    } catch (e: any) {
      this.error.set(e.message || 'មានកំហុសមិនស្គាល់មួយបានកើតឡើង។');
    } finally {
      this.isLoading.set(false);
    }
  }

  updatePrompt(event: Event) {
    const input = event.target as HTMLTextAreaElement;
    this.prompt.set(input.value);
  }
}
