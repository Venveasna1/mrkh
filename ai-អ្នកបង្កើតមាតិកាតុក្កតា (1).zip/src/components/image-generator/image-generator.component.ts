
import { Component, ChangeDetectionStrategy, inject, signal } from '@angular/core';
import { GeminiService } from '../../services/gemini.service';

@Component({
  selector: 'app-image-generator',
  templateUrl: './image-generator.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ImageGeneratorComponent {
  private geminiService = inject(GeminiService);

  prompt = signal('មនុស្សយន្តរីករាយកំពុងគ្រវីសួស្តី ឈរនៅវាលផ្កា។');
  result = signal<string | null>(null);
  isLoading = signal(false);
  error = signal<string | null>(null);

  async generateImage() {
    if (!this.prompt().trim()) return;

    this.isLoading.set(true);
    this.result.set(null);
    this.error.set(null);

    try {
      const imageUrl = await this.geminiService.generateImage(this.prompt());
      this.result.set(imageUrl);
    } catch (e: any) {
      this.error.set(e.message || 'មានកំហុសមិនស្គាល់មួយបានកើតឡើង។');
    } finally {
      this.isLoading.set(false);
    }
  }

  updatePrompt(event: Event) {
    const input = event.target as HTMLTextAreaElement;
    this.prompt.set(input.value);
  }
}
