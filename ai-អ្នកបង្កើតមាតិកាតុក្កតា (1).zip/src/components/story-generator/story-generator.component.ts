
import { Component, ChangeDetectionStrategy, inject, signal } from '@angular/core';
import { GeminiService } from '../../services/gemini.service';

@Component({
  selector: 'app-story-generator',
  templateUrl: './story-generator.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class StoryGeneratorComponent {
  private geminiService = inject(GeminiService);

  prompt = signal('កំប្រុកដែលចង់ដឹងចង់ឃើញ ដែលរកឃើញផ្លេសេនវេទមន្តដែលភ្លឺ។');
  result = signal<string | null>(null);
  isLoading = signal(false);
  error = signal<string | null>(null);

  translatedResult = signal<string | null>(null);
  isTranslating = signal(false);

  async generateStory() {
    if (!this.prompt().trim()) return;

    this.isLoading.set(true);
    this.result.set(null);
    this.translatedResult.set(null);
    this.error.set(null);

    try {
      const story = await this.geminiService.generateStory(this.prompt());
      this.result.set(story);
    } catch (e: any) {
      this.error.set(e.message || 'មានកំហុសមិនស្គាល់មួយបានកើតឡើង។');
    } finally {
      this.isLoading.set(false);
    }
  }
  
  async translateStory() {
    if (!this.result()) return;

    this.isTranslating.set(true);
    this.translatedResult.set(null);
    this.error.set(null);

    try {
      const translated = await this.geminiService.translateText(this.result()!, 'Khmer');
      this.translatedResult.set(translated);
    } catch (e: any) {
      this.error.set(e.message || 'មានកំហុសមិនស្គាល់មួយបានកើតឡើង។');
    } finally {
      this.isTranslating.set(false);
    }
  }

  updatePrompt(event: Event) {
    const input = event.target as HTMLTextAreaElement;
    this.prompt.set(input.value);
  }
}
